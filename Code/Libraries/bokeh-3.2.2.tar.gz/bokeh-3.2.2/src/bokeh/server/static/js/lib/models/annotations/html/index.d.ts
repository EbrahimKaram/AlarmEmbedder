export { HTMLLabel } from "./label";
export { HTMLLabelSet } from "./label_set";
export { HTMLTitle } from "./title";
//# sourceMappingURL=index.d.ts.map