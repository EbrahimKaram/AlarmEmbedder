import type { RenderItem } from "./json";
export type EmbedTarget = HTMLElement | DocumentFragment;
export declare function _resolve_element(item: RenderItem): EmbedTarget;
export declare function _resolve_root_elements(item: RenderItem): EmbedTarget[];
//# sourceMappingURL=dom.d.ts.map