export { CoordinateMapping } from "./coordinate_mapping";
//# sourceMappingURL=index.d.ts.map