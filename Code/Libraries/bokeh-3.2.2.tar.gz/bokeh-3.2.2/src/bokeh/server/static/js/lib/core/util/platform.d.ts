import type { ByteOrder } from "../types";
export declare const is_mobile: boolean;
export declare const is_little_endian: boolean;
export declare const BYTE_ORDER: ByteOrder;
export declare function to_big_endian(values: Uint32Array): Uint32Array;
//# sourceMappingURL=platform.d.ts.map